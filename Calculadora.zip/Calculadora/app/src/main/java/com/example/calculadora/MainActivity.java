package com.example.calculadora;

import android.annotation.SuppressLint;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView display;
    private String currentText = "";

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        display = findViewById(R.id.display);


        Button button1 = findViewById(R.id.button1);
        Button button2 = findViewById(R.id.button2);
        Button button3 = findViewById(R.id.button3);
        Button button4 = findViewById(R.id.button4);
        Button button5 = findViewById(R.id.button5);
        Button button6 = findViewById(R.id.button6);
        Button button7 = findViewById(R.id.button7);
        Button button8 = findViewById(R.id.button8);
        Button button9 = findViewById(R.id.button9);
        Button button0 = findViewById(R.id.button0);
        Button buttonPlus = findViewById(R.id.buttonPlus);
        Button buttonMinus = findViewById(R.id.buttonMinus);
        Button buttonEquals = findViewById(R.id.buttonEquals);
        Button buttonClear = findViewById(R.id.buttonClear);


        button1.setOnClickListener(v -> appendToDisplay("1"));
        button2.setOnClickListener(v -> appendToDisplay("2"));
        button3.setOnClickListener(v -> appendToDisplay("3"));
        button4.setOnClickListener(v -> appendToDisplay("4"));
        button5.setOnClickListener(v -> appendToDisplay("5"));
        button6.setOnClickListener(v -> appendToDisplay("6"));
        button7.setOnClickListener(v -> appendToDisplay("7"));
        button8.setOnClickListener(v -> appendToDisplay("8"));
        button9.setOnClickListener(v -> appendToDisplay("9"));
        button0.setOnClickListener(v -> appendToDisplay("0"));
        buttonPlus.setOnClickListener(v -> appendToDisplay("+"));
        buttonMinus.setOnClickListener(v -> appendToDisplay("-"));

        buttonClear.setOnClickListener(v -> {
            currentText = "";
            display.setText(currentText);
        });

        buttonEquals.setOnClickListener(v -> {
            try {
                int result = calculate(currentText);
                display.setText(String.valueOf(result));
            } catch (Exception e) {
                display.setText("-1");
            }
        });
    }

    private void appendToDisplay(String value) {
        currentText += value;
        display.setText(currentText);
    }


    private int calculate(String expression) throws IllegalArgumentException {
        if (!expression.contains("+") && !expression.contains("-")) {
            try {
                return Integer.parseInt(expression);
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("Error en la cadena");
            }
        }

        if (expression.contains("+")) {
            String[] parts = expression.split("\\+", 2);
            if (parts.length != 2 || parts[0].isEmpty() || parts[1].isEmpty()) {
                throw new IllegalArgumentException("Error en la cadena");
            }

            int leftPart = calculate(parts[0]);
            int rightPart = calculate(parts[1]);
            return leftPart + rightPart;
        }


        String[] parts = expression.split("-", 2);
        if (parts.length != 2 || parts[0].isEmpty() || parts[1].isEmpty()) {
            throw new IllegalArgumentException("Error en la cadena");
        }

        int leftPart = calculate(parts[0]);
        int rightPart = calculate(parts[1]);
        return leftPart - rightPart;
    }
}
